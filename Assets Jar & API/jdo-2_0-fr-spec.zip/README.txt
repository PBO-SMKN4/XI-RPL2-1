This is the final release of JSR-243, Java Data Objects 2.0.

The reference implementation is JPOX 1.1.0, available from http://jpox.org.
License terms: Apache 2.0 license http://apache.org/licenses/LICENSE-2.0.

The technology compatibility kit is Apache JDO project tck20, available from http://db.apache.org/jdo.
License terms: Apache 2.0 license http://apache.org/licenses/LICENSE-2.0.

